package batch.rest;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;

@RestController
public class CustomerRestController {

	@Autowired
	private JobLauncher jobLauncher;
	
	@Autowired
	private Job job;

	@PostMapping("/upload")
	public String uploadFile(@RequestParam("file")MultipartFile file){
		System.out.println("uploadFile initiated");
		System.out.println(System.getProperty("user.dir"));
		String filePath = System.getProperty("user.dir") + "/" + file.getOriginalFilename();
		String fileUploadStatus;
		try {
			FileOutputStream fout = new FileOutputStream(filePath);
			fout.write(file.getBytes());
			fout.close();
			fileUploadStatus = "File Uploaded Successfully";
			JobParameters jobParams = new JobParametersBuilder()
					.addLong("startAt", System.currentTimeMillis()).toJobParameters();
			jobLauncher.run(job, jobParams);
		}
		catch (Exception e) {
			e.printStackTrace();
			fileUploadStatus =  "Error in uploading file: " + e;
		}
		return fileUploadStatus;
	}
}


